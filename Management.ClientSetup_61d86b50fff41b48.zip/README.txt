Management Client - Offline Install
Build: 61d86b50fff41b48
Service: Management Solutions
Install dir: %ProgramFiles(x86)%\Management Solutions

USAGE
-----
1. Extract this ZIP to any folder on the target machine.
2. Open PowerShell as Administrator (right-click - Run as administrator).
3. cd to the extracted folder.
4. Pick ONE of the following:

   A) PASTE METHOD (no execution-policy change needed)
      Open install.ps1 in Notepad, select all (Ctrl+A), copy (Ctrl+C),
      then paste into the PowerShell window and press Enter. Pasted code
      isn't a script file, so PowerShell's execution policy doesn't apply.

   B) FILE METHOD
      Run:
          Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
          .\install.ps1
      The Set-ExecutionPolicy line only affects this PowerShell window.

Both methods do the same thing: copy files into
%ProgramFiles(x86)%\Management Solutions\, create the Windows service, and start it.
Re-running install replaces the existing install.

UNINSTALL
---------
Same two methods using uninstall.ps1. Stops & deletes the service, then
removes the install folder. No registry footprint outside the unavoidable
service entry under HKLM\SYSTEM\CurrentControlSet\Services\<service>, which
"sc.exe delete" removes.

TROUBLESHOOTING
---------------
- "This script needs Administrator": reopen PowerShell as Administrator.
- "files\ folder not found": cd into the extracted folder first.
- Service fails to start: check Event Viewer - Windows Logs - Application,
  filter by source "Management Solutions".
- Service runs but doesn't connect: confirm the target machine can reach
  the configured server/port (baked into install.ps1's $ServiceArgs).
