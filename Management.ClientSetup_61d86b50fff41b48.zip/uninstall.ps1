& {
    $ErrorActionPreference = 'SilentlyContinue'

    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) {
        if ($PSCommandPath) {
            Write-Host "Re-launching elevated..." -ForegroundColor Yellow
            $argList = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
            Start-Process -FilePath powershell.exe -Verb RunAs -ArgumentList $argList
            return
        }
        Write-Warning "This script needs Administrator. Close this window, reopen PowerShell as Administrator, then paste again."
        return
    }

    $ServiceName = 'Management Solutions'
    $DirName     = 'Management Solutions'

    $existing = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Host "Stopping & removing service: $ServiceName"
        if ($existing.Status -ne 'Stopped') {
            Stop-Service -Name $ServiceName -Force
            Start-Sleep -Seconds 1
        }
        & sc.exe delete $ServiceName | Out-Null
        Start-Sleep -Seconds 2
    } else {
        Write-Host "Service not present: $ServiceName"
    }

    $candidates = @(
        (Join-Path ${env:ProgramFiles(x86)} $DirName),
        (Join-Path $env:ProgramFiles $DirName)
    )
    foreach ($p in $candidates) {
        if (Test-Path $p) {
            Get-Process -ErrorAction SilentlyContinue |
                Where-Object { $_.Path -and $_.Path.StartsWith($p, [StringComparison]::OrdinalIgnoreCase) } |
                ForEach-Object { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue }
            Start-Sleep -Milliseconds 500
            Write-Host "Removing folder: $p"
            Remove-Item -Path $p -Recurse -Force
        }
    }

    Write-Host ""
    Write-Host "Uninstalled: $ServiceName" -ForegroundColor Green
}
